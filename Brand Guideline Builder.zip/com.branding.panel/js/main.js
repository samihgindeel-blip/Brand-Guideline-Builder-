/* Brand Guidelines Generator - panel logic (runs in the CEP panel). */
(function () {
    "use strict";

    var cep = window.__adobe_cep__;
    var IN_HOST = !!(cep && cep.evalScript);
    var STORE_KEY = "bgg.state.v2";

    var ROLES = [
        { id: "primary", label: "Primary", required: true },
        { id: "secondary", label: "Secondary" },
        { id: "tertiary", label: "Tertiary" },
        { id: "additional1", label: "Additional 1" },
        { id: "additional2", label: "Additional 2" },
        { id: "additional3", label: "Additional 3" }
    ];
    var SLOT_LABELS = { fulllogo: "Full logo", logomark: "Logo mark", logotype: "Logotype" };
    var SLOT_HINTS = { fulllogo: "Mark + name", logomark: "Icon / symbol", logotype: "Name only" };

    var DEFAULT_STATE = {
        brand: "",
        logos: { fulllogo: null, logomark: null, logotype: null },
        colors: {
            primary: { hex: "#FF6A00", on: true },
            secondary: { hex: "#1F2A44", on: true },
            tertiary: { hex: "#00B3A4", on: true },
            additional1: { hex: "#FFC48C", on: false },
            additional2: { hex: "#9AA3B5", on: false },
            additional3: { hex: "#8F4A22", on: false }
        },
        fonts: { header: "", subheader: "", body: "" },
        template: "corporate/template.ai"
    };

    var DEMO_TEMPLATES = [
        { id: "corporate/template.ai", name: "Corporate", description: "40-page corporate brandbook", pages: 40, thumbnail: "templates/corporate/thumbs/template.png" },
        { id: "modern/template.ai", name: "Modern", description: "100-page brandbook with mockups", pages: 100, thumbnail: "templates/modern/thumbs/template.png" }
    ];

    var state = loadState();
    var templates = [];
    var busy = false;

    /* ---------------- utils ---------------- */
    function $(sel, root) { return (root || document).querySelector(sel); }
    function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
    function fileUrl(p) {
        if (!p) return "";
        if (!IN_HOST && !/^[A-Za-z]:|^\//.test(p)) return p; // relative path in browser preview
        p = String(p).replace(/\\/g, "/");
        return "file://" + (p.charAt(0) === "/" ? "" : "/") + encodeURI(p).replace(/#/g, "%23");
    }
    function normHex(v) {
        v = String(v || "").trim().replace(/^#/, "");
        if (/^[0-9a-f]{3}$/i.test(v)) v = v.replace(/(.)/g, "$1$1");
        return /^[0-9a-f]{6}$/i.test(v) ? "#" + v.toUpperCase() : null;
    }
    function clone(o) { return JSON.parse(JSON.stringify(o)); }

    function loadState() {
        var base = clone(DEFAULT_STATE);
        try {
            var s = JSON.parse(localStorage.getItem(STORE_KEY));
            if (s) {
                if (typeof s.brand === "string") base.brand = s.brand;
                if (s.logos) for (var k in base.logos) if (s.logos[k] !== undefined) base.logos[k] = s.logos[k];
                if (s.colors) for (var c in base.colors) if (s.colors[c]) base.colors[c] = s.colors[c];
                if (s.fonts) for (var f in base.fonts) if (typeof s.fonts[f] === "string") base.fonts[f] = s.fonts[f];
                if (s.template) base.template = s.template;
            }
        } catch (e) { /* ignore */ }
        return base;
    }
    function saveState() { try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); } catch (e) { /* ignore */ } }

    function extensionRoot() {
        if (!IN_HOST) return "";
        var p = decodeURI(cep.getSystemPath("extension"));
        if (/^file:\/\/\/[A-Za-z]:/.test(p)) p = p.replace("file:///", "");
        else p = p.replace("file://", "");
        return p;
    }

    /* Calls a BG_* function in host.jsx and resolves with its data. */
    function host(fn, args) {
        return new Promise(function (resolve, reject) {
            if (!IN_HOST) { reject(new Error("Preview mode: open this panel inside Illustrator (Window > Extensions).")); return; }
            var code = fn + "(" + (args || []).map(function (a) { return JSON.stringify(a); }).join(",") + ")";
            cep.evalScript(code, function (res) {
                if (!res || res === "EvalScript error.") { reject(new Error("Illustrator script error. Try reopening the panel.")); return; }
                var o;
                try { o = JSON.parse(res); } catch (e) { reject(new Error(String(res))); return; }
                if (o.ok) resolve(o.data); else reject(new Error(o.error));
            });
        });
    }

    function setStatus(msg, kind) {
        var el = $("#status");
        el.className = "status" + (kind ? " " + kind : "");
        el.innerHTML = (kind === "busy" ? '<span class="spinner"></span>' : "") + esc(msg);
    }
    function setBusy(on, msg) {
        busy = on;
        $all("button").forEach(function (b) { b.disabled = on; });
        if (on) setStatus(msg || "Working...", "busy");
    }
    function run(msg, promiseFn) {
        if (busy) return Promise.resolve();
        setBusy(true, msg);
        return Promise.resolve().then(promiseFn).then(function (r) {
            setBusy(false); return r;
        }, function (err) {
            setBusy(false); setStatus(err.message || String(err), "err");
        });
    }

    /* ---------------- host theme ---------------- */
    function applyHostTheme() {
        if (!IN_HOST || !cep.getHostEnvironment) return;
        try {
            var env = JSON.parse(cep.getHostEnvironment());
            var c = env.appSkinInfo.panelBackgroundColor.color;
            var r = Math.round(c.red), g = Math.round(c.green), b = Math.round(c.blue);
            var light = (r + g + b) / 3 > 128;
            var root = document.documentElement.style;
            root.setProperty("--bg", "rgb(" + r + "," + g + "," + b + ")");
            if (light) {
                root.setProperty("--card", "rgba(0,0,0,.05)");
                root.setProperty("--card-2", "rgba(0,0,0,.07)");
                root.setProperty("--border", "rgba(0,0,0,.15)");
                root.setProperty("--text", "#1b1b1b");
                root.setProperty("--muted", "#5f5f5f");
            } else {
                root.setProperty("--card", "rgba(255,255,255,.05)");
                root.setProperty("--card-2", "rgba(255,255,255,.07)");
            }
        } catch (e) { /* keep defaults */ }
    }

    /* ---------------- brand + fonts ---------------- */
    function initFields() {
        var b = $("#brand");
        b.value = state.brand;
        b.addEventListener("input", function () { state.brand = b.value; saveState(); });
        ["header", "subheader", "body"].forEach(function (k) {
            var el = $("#font-" + k);
            el.value = state.fonts[k] || "";
            el.addEventListener("input", function () { state.fonts[k] = el.value.trim(); saveState(); });
        });
    }

    /* ---------------- logos ---------------- */
    function renderLogos() {
        $all(".logo-slot").forEach(function (slot) {
            var key = slot.getAttribute("data-slot"), info = state.logos[key];
            var prev = $(".logo-preview", slot), name = $(".logo-name", slot);
            slot.classList.toggle("filled", !!info);
            if (info) {
                prev.innerHTML = info.preview
                    ? '<img alt="" src="' + esc(fileUrl(info.preview)) + '">'
                    : '<span class="logo-empty">' + esc((info.name.split(".").pop() || "").toUpperCase()) + " file</span>";
                name.textContent = info.name;
                name.title = info.path;
                var img = $("img", prev);
                if (img) img.onerror = function () { prev.innerHTML = '<span class="logo-empty">Loaded</span>'; };
            } else {
                prev.innerHTML = '<span class="logo-empty">' + SLOT_LABELS[key] + "</span>";
                name.textContent = SLOT_HINTS[key];
                name.title = "";
            }
        });
    }
    function initLogos() {
        $all(".logo-slot").forEach(function (slot) {
            var key = slot.getAttribute("data-slot");
            slot.addEventListener("click", function (e) {
                var act = e.target.getAttribute && e.target.getAttribute("data-act");
                if (!act) return;
                if (act === "clear") { state.logos[key] = null; saveState(); renderLogos(); return; }
                var fn = act === "file" ? "BG_pickLogo" : "BG_captureSelection";
                run(act === "file" ? "Waiting for file..." : "Capturing selection...", function () {
                    return host(fn).then(function (info) {
                        if (!info) { setStatus(""); return; }
                        state.logos[key] = info; saveState(); renderLogos();
                        setStatus(SLOT_LABELS[key] + " ready", "ok");
                    });
                });
            });
        });
        renderLogos();
    }

    /* ---------------- colors ---------------- */
    function renderColors() {
        var list = $("#color-list");
        list.innerHTML = "";
        ROLES.forEach(function (role) {
            var c = state.colors[role.id];
            var row = document.createElement("div");
            row.className = "color-row" + (c.on || role.required ? "" : " off");
            row.innerHTML =
                (role.required ? '<span class="tick-spacer"></span>' : '<input class="tick" type="checkbox" title="Use this color"' + (c.on ? " checked" : "") + ">") +
                '<label class="color-chip" style="background:' + esc(c.hex) + '"><input type="color" value="' + esc(c.hex.toLowerCase()) + '"></label>' +
                '<input class="hex" type="text" value="' + esc(c.hex) + '" maxlength="7" spellcheck="false">' +
                '<span class="role-name">' + role.label + "</span>" +
                '<span class="auto">' + (c.on || role.required ? "" : "auto") + "</span>";
            var chip = $(".color-chip", row), picker = $("input[type=color]", row), hex = $(".hex", row), tick = $(".tick", row);
            function turnOn() { if (!c.on && tick) { c.on = true; tick.checked = true; row.classList.remove("off"); $(".auto", row).textContent = ""; } }
            picker.addEventListener("input", function () {
                c.hex = picker.value.toUpperCase(); hex.value = c.hex; chip.style.background = c.hex; hex.classList.remove("bad"); turnOn(); saveState();
            });
            hex.addEventListener("input", function () {
                var v = normHex(hex.value);
                hex.classList.toggle("bad", !v);
                if (v) { c.hex = v; picker.value = v.toLowerCase(); chip.style.background = v; turnOn(); saveState(); }
            });
            hex.addEventListener("blur", function () { hex.value = c.hex; hex.classList.remove("bad"); });
            if (tick) tick.addEventListener("change", function () { c.on = tick.checked; saveState(); renderColors(); });
            list.appendChild(row);
        });
    }
    function initColors() {
        $("#colors-from-sel").addEventListener("click", function () {
            run("Reading colors from selection...", function () {
                return host("BG_colorsFromSelection").then(function (hexes) {
                    if (!hexes || !hexes.length) { setStatus("No solid fill colors found in the selection.", "err"); return; }
                    ROLES.forEach(function (role, i) {
                        if (hexes[i]) state.colors[role.id] = { hex: hexes[i], on: true };
                        else if (!role.required) state.colors[role.id].on = false;
                    });
                    saveState(); renderColors();
                    setStatus(hexes.length + " colors picked in order: Primary, Secondary, ...", "ok");
                });
            });
        });
        renderColors();
    }

    /* ---------------- templates ---------------- */
    function renderTemplates() {
        var grid = $("#template-grid");
        if (!templates.length) { grid.innerHTML = '<div class="hint">Loading templates...</div>'; return; }
        grid.innerHTML = "";
        templates.forEach(function (t) {
            var card = document.createElement("div");
            card.className = "tpl" + (t.id === state.template ? " active" : "");
            card.title = t.file || "";
            card.innerHTML =
                '<div class="tpl-thumb">' + (t.thumbnail ? '<img alt="" src="' + esc(fileUrl(t.thumbnail)) + '">' : "") +
                (t.pages ? '<span class="tpl-pages">' + t.pages + (t.pages === 1 ? " page" : " pages") + "</span>" : "") + "</div>" +
                '<div class="tpl-info"><div class="tpl-name"><span>' + esc(t.name) + '</span><span class="check">&#10003;</span></div>' +
                '<div class="tpl-desc">' + esc(t.description) + "</div></div>";
            var img = $("img", card);
            if (img) img.onerror = function () { img.remove(); };
            card.addEventListener("click", function () { state.template = t.id; saveState(); renderTemplates(); });
            grid.appendChild(card);
        });
    }
    function loadTemplates() {
        if (!IN_HOST) { templates = DEMO_TEMPLATES; renderTemplates(); return; }
        host("BG_listTemplates", [extensionRoot()]).then(function (list) {
            templates = list || [];
            if (!templates.length) { setStatus("No .ai templates found in the templates folder.", "err"); return; }
            if (!templates.some(function (t) { return t.id === state.template; })) { state.template = templates[0].id; saveState(); }
            renderTemplates();
            var missing = templates.some(function (t) { return !t.hasThumb; });
            if (missing) {
                setStatus("Creating template previews (first run only)...", "busy");
                host("BG_buildThumbnails", [extensionRoot(), false]).then(function () {
                    return host("BG_listTemplates", [extensionRoot()]);
                }).then(function (l2) { templates = l2 || templates; renderTemplates(); setStatus(""); },
                    function () { setStatus(""); });
            }
        }, function (err) {
            setStatus("Could not read templates folder: " + err.message, "err");
        });
    }

    /* ---------------- generate / export ---------------- */
    function buildPayload() {
        var logos = {};
        Object.keys(state.logos).forEach(function (k) { logos[k] = state.logos[k] ? state.logos[k].path : ""; });
        return {
            root: extensionRoot(),
            brand: state.brand.trim() || "Your Brand",
            template: state.template,
            colors: ROLES.filter(function (r) { return r.required || state.colors[r.id].on; })
                .map(function (r) { return { role: r.id, hex: state.colors[r.id].hex }; }),
            logos: logos,
            fonts: { header: state.fonts.header || "", subheader: state.fonts.subheader || "", body: state.fonts.body || "" }
        };
    }
    function initActions() {
        $("#generate").addEventListener("click", function () {
            var payload = buildPayload();
            if (!payload.logos.fulllogo && !payload.logos.logomark && !payload.logos.logotype) { setStatus("Add at least one logo first (step 2).", "err"); return; }
            var t0 = Date.now();
            run("Applying your brand to the template...", function () {
                return host("BG_generate", [payload]).then(function (r) {
                    var secs = ((Date.now() - t0) / 1000).toFixed(1);
                    setStatus("Done in " + secs + "s: " + r.artboards + " pages, " + r.logos + " logos placed. Saved as " + r.file, "ok");
                });
            });
        });
        $("#export-pdf").addEventListener("click", function () {
            run("Exporting PDF...", function () {
                return host("BG_exportPDF").then(function (r) { setStatus(r ? "PDF saved: " + r.file : "", r ? "ok" : ""); });
            });
        });
        $("#export-png").addEventListener("click", function () {
            run("Exporting PNG pages...", function () {
                return host("BG_exportPNG").then(function (r) { setStatus(r ? r.count + " PNGs saved to " + r.folder : "", r ? "ok" : ""); });
            });
        });
    }

    /* ---------------- boot ---------------- */
    function boot() {
        applyHostTheme();
        initFields(); initLogos(); initColors(); initActions();
        if (IN_HOST) {
            var root = extensionRoot().replace(/\\/g, "/");
            // (Re)load the host script so the panel always runs the current host.jsx.
            cep.evalScript('$.evalFile("' + root + '/jsx/host.jsx"); "1"', function () { loadTemplates(); });
        } else {
            loadTemplates();
            setStatus("Preview mode: open inside Illustrator to generate.", "");
        }
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
