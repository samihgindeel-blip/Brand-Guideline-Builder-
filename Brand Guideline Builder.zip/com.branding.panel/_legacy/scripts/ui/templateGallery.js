const templates = [
    { id: 'modern-1', name: 'Modern Alpha', path: 'modern' },
    { id: 'modern-2', name: 'Modern Beta', path: 'modern' },
    { id: 'corporate-1', name: 'Corp Standard', path: 'corporate' },
    { id: 'corporate-2', name: 'Corp Executive', path: 'corporate' },
    { id: 'minimal-1', name: 'Minimal Light', path: 'minimal' },
    { id: 'minimal-2', name: 'Minimal Dark', path: 'minimal' },
    { id: 'creative-1', name: 'Creative Pop', path: 'creative' },
    { id: 'creative-2', name: 'Creative Flow', path: 'creative' }
];

export let selectedTemplateId = 'modern-1'; // Default

export function initTemplateGallery() {
    const gallery = document.getElementById('templateGallery');
    
    templates.forEach(t => {
        const card = document.createElement('div');
        card.className = `template-card ${t.id === selectedTemplateId ? 'active' : ''}`;
        card.dataset.id = t.id;
        
        // Utilizing the file structure requested: thumbnail.png
        card.innerHTML = `
            <img src="../templates/${t.path}/thumbnail.png" alt="${t.name}" onerror="this.src='../assets/placeholders/emptyTemplate.png'">
            <div class="template-info">
                <span class="template-name">${t.name}</span>
                <span class="check-indicator">✔</span>
            </div>
        `;
        
        card.addEventListener('click', () => {
            document.querySelectorAll('.template-card').forEach(c => c.classList.remove('active'));
            card.classList.add('active');
            selectedTemplateId = t.id;
        });
        
        gallery.appendChild(card);
    });
}