import { previewController } from '../controllers/previewController.js';

export const previewPanel = {
    init() {
        this.root = document.getElementById("preview-panel-root");
        this.update();
    },
    async update() {
        this.root.innerHTML = `
            <div style="display:flex; flex-direction:column; align-items:center; padding:20px;">
                <span style="color:var(--accent-orange); font-size:11px; letter-spacing:1px;">GENERATING PREVIEW VIEWPORT...</span>
            </div>
        `;
        
        const imgUri = await previewController.getLivePreviewUri();
        
        this.root.innerHTML = `
            <div class="live-preview-box">
                <div style="padding: 10px; font-weight: bold; border-bottom: 1px solid var(--border-color); display:flex; justify-content:space-between; align-items:center;">
                    <span>LIVE ARTBOARD PREVIEW</span>
                    <span id="active-tag" style="font-size:10px; color:var(--accent-orange); background:rgba(255,106,0,0.1); padding:2px 6px; border-radius:3px;">ACTIVE</span>
                </div>
                <div class="preview-stage" id="main-preview-viewport">
                    <img src="${imgUri}" id="live-preview-img" alt="Active State Frame" style="display:block; max-width:100%; height:auto;">
                </div>
            </div>
        `;

        const imgElement = this.root.querySelector("#live-preview-img");
        
        // Handle format auto-switching (.png vs .jpg fallbacks)
        imgElement.onerror = () => {
            if (imgElement.src.endsWith(".png")) {
                // If png failed, try looking for the jpg variant
                imgElement.src = imgElement.src.replace(".png", ".jpg");
            } else {
                // Both failed -> Draw UI CSS preview canvas box
                const viewport = this.root.querySelector("#main-preview-viewport");
                viewport.innerHTML = `
                    <div style="width:100%; height:180px; display:flex; flex-direction:column; align-items:center; justify-content:center; background:#181818; border:1px dashed var(--accent-orange); border-radius:4px; padding:16px; box-sizing:border-box;">
                        <div style="font-size:24px; margin-bottom:8px;">📐</div>
                        <div style="font-weight:bold; color:#fff; margin-bottom:4px; font-size:11px;">Template Matrix Generated</div>
                        <div style="color:var(--text-muted); font-size:10px; text-align:center;">Preview image file not found in folder. Check image file extensions.</div>
                    </div>
                `;
            }
        };
    }
};