import { brandingController } from '../controllers/brandingController.js';

export const colorForm = {
    init() {
        this.root = document.getElementById("color-form-root");
        this.render();
    },
    render() {
        const colors = brandingController.getColors();
        this.root.innerHTML = `<div class="color-picker-grid"></div>`;
        const grid = this.root.querySelector(".color-picker-grid");

        colors.forEach((color, idx) => {
            const block = document.createElement("div");
            block.className = "color-input-block";
            block.innerHTML = `
                <input type="color" value="${color}" data-idx="${idx}">
                <span style="font-size:9px; margin-top:4px;">Color ${idx+1}</span>
            `;
            block.querySelector("input").addEventListener("input", (e) => {
                brandingController.updateColor(parseInt(e.target.dataset.idx), e.target.value);
            });
            grid.appendChild(block);
        });
    }
};