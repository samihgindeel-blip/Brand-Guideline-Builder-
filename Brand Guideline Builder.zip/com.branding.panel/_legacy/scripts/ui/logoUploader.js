import { brandingController } from '../controllers/brandingController.js';

export const logoUploader = {
    init() {
        this.root = document.getElementById("logo-uploader-root");
        this.render();
    },
    render() {
        this.root.innerHTML = `
            <div class="dropzone-container" id="logo-dropzone">
                <p>Click to load Vector Logo asset</p>
            </div>
            <div id="logo-file-details"></div>
        `;

        const zone = this.root.querySelector("#logo-dropzone");
        zone.addEventListener("click", async () => {
            const file = await brandingController.requestLogoFile();
            if(file) {
                this.updateDetails(file.name);
            }
        });
    },
    updateDetails(name) {
        const target = this.root.querySelector("#logo-file-details");
        target.innerHTML = `
            <div class="file-preview-row">
                <span style="color: #ff6a00; font-weight:bold;">✓</span>
                <span>${name} Loaded</span>
            </div>
        `;
    }
};