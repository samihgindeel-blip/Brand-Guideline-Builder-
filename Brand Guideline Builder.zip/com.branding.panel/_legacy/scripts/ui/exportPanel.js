import { exportController } from '../controllers/exportController.js';

export const exportPanel = {
    init() {
        this.root = document.getElementById("export-panel-root");
        this.render();
    },
    render() {
        this.root.innerHTML = `
            <button class="cta-btn" id="btn-build-doc" style="width: 100%; margin-bottom: 8px;">BUILD ILLUSTRATOR DOCUMENT</button>
            <div class="export-row">
                <button id="btn-exp-pdf" style="background:#333; color:#fff; border:1px solid #555; padding:8px; border-radius:4px; cursor:pointer;">Export PDF</button>
                <button id="btn-exp-png" style="background:#333; color:#fff; border:1px solid #555; padding:8px; border-radius:4px; cursor:pointer;">Export PNG Package</button>
            </div>
        `;

        this.root.querySelector("#btn-build-doc").addEventListener("click", () => exportController.triggerBuild());
        this.root.querySelector("#btn-exp-pdf").addEventListener("click", () => exportController.triggerExport("pdf"));
        this.root.querySelector("#btn-exp-png").addEventListener("click", () => exportController.triggerExport("png"));
    }
};