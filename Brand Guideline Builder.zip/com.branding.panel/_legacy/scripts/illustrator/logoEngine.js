export const logoEngine = {
    async injectLogo(doc, fileReference) {
        console.log("Placing raw local storage reference file item onto layer space:", fileReference.name);
    }
};