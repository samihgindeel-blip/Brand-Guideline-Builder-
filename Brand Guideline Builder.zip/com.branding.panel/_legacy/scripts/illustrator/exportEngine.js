export const exportEngine = {
    async writeDiskOutput() {
        return true;
    }
};