export const thumbnailEngine = {
    async parseThumbnailStream() {
        return null;
    }
};