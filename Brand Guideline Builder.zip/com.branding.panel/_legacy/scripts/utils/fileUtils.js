export const fileUtils = {
    async readJsonFile(file) {
        const text = await file.read();
        return JSON.parse(text);
    }
};