export const validationUtils = {
    verifyPayloadStructure(data) {
        return !!(data && data.templateId && data.colors);
    }
};