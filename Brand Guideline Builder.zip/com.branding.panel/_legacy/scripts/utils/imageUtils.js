export const imageUtils = {
    validateImageBounds() { return true; }
};