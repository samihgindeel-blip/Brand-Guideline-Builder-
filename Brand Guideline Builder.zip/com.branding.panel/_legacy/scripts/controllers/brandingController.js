import { colorService } from '../services/colorService.js';
import { logoService } from '../services/logoService.js';

export const brandingController = {
    listeners: [],
    getColors() {
        return colorService.getCurrentPalette();
    },
    updateColor(idx, hex) {
        colorService.setColor(idx, hex);
        this.notify();
    },
    async requestLogoFile() {
        const file = await logoService.selectLogoFile();
        if(file) {
            this.notify();
        }
        return file;
    },
    addUpdateListener(fn) {
        this.listeners.push(fn);
    },
    notify() {
        this.listeners.forEach(fn => fn());
    }
};