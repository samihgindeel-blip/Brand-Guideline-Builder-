import { guidelineService } from '../services/guidelineService.js';
import { templateController } from './templateController.js';
import { colorService } from '../services/colorService.js';
import { logoService } from '../services/logoService.js';

export const exportController = {
    async triggerBuild() {
        const payload = this.assemblePayload();
        await guidelineService.generateVectorDocument(payload);
    },
    async triggerExport(format) {
        const payload = this.assemblePayload();
        await guidelineService.exportFormat(format, payload);
    },
    assemblePayload() {
        return {
            templateId: templateController.getSelectedTemplateId(),
            colors: colorService.getCurrentPalette(),
            logoFile: logoService.getActiveLogoFile()
        };
    }
};