import { templateService } from '../services/templateService.js';

export const templateController = {
    currentTemplateId: "modern",
    async getAvailableTemplates() {
        return await templateService.fetchTemplates();
    },
    selectTemplate(id) {
        this.currentTemplateId = id;
    },
    getSelectedTemplateId() {
        return this.currentTemplateId;
    }
};