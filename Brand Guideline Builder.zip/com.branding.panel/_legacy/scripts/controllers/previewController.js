import { thumbnailService } from '../services/thumbnailService.js';
import { templateController } from './templateController.js';

export const previewController = {
    async getLivePreviewUri() {
        const currentTpl = templateController.getSelectedTemplateId();
        return await thumbnailService.getThumbnailForTemplate(currentTpl);
    }
};