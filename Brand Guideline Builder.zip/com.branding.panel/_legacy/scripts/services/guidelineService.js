import { illustratorApi } from '../illustrator/illustratorApi.js';

export const guidelineService = {
    async generateVectorDocument(data) {
        if(!data.logoFile) {
            alert("Please supply a baseline vector logo source first.");
            return;
        }
        await illustratorApi.buildEnginePipeline(data);
    },
    async exportFormat(format, data) {
        await illustratorApi.executeExportCommand(format, data);
    }
};