export const thumbnailService = {
    async getThumbnailForTemplate(id) {
        // Fallback placeholder paths mapping directly to native container bindings
        return "assets/placeholders/noPreview.png";
    }
};