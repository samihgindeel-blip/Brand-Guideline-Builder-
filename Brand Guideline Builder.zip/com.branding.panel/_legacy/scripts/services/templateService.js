export const templateService = {
    async fetchTemplates() {
        return [
            { 
                id: "modern", 
                name: "Modern Minimalist", 
                description: "Clean layouts with bold asymmetric design elements.", 
                thumbnailPath: "./templates/modern/thumbnail.png" 
            },
            { 
                id: "corporate", 
                name: "Corporate Classic", 
                description: "Structured columns optimized for strict institutional workflows.", 
                thumbnailPath: "./templates/corporate/thumbnail.png" 
            },
            { 
                id: "minimal", 
                name: "Ultra Minimal", 
                description: "Clean, high-whitespace layouts for understated elegance.", 
                thumbnailPath: "./templates/minimal/thumbnail.png" 
            },
            { 
                id: "creative", 
                name: "Creative Editorial", 
                description: "Dynamic structures focusing on image containers.", 
                thumbnailPath: "./templates/creative/thumbnail.png" 
            }
        ];
    }
};