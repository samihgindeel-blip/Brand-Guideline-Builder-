const storage = require("uxp").storage;
const fs = storage.localFileSystem;

export const logoService = {
    logoFile: null,
    async selectLogoFile() {
        try {
            const file = await fs.getFileForOpening({ types: ["ai", "eps", "svg", "png"] });
            if (file) {
                this.logoFile = file;
                return file;
            }
        } catch (e) {
            console.error("User canceled or read operation structural failure", e);
        }
        return null;
    },
    getActiveLogoFile() {
        return this.logoFile;
    }
};