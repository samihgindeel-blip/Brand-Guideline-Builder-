export const configService = {
    async loadConfig(templateId) {
        return { targetArtboards: 4, dimensions: { width: 1920, height: 1080 } };
    }
};