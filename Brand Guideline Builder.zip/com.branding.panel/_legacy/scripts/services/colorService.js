export const colorService = {
    palette: ["#ff6a00", "#1a1a1a", "#ffffff", "#7f8c8d"],
    getCurrentPalette() {
        return this.palette;
    },
    setColor(idx, hex) {
        this.palette[idx] = hex;
    }
};