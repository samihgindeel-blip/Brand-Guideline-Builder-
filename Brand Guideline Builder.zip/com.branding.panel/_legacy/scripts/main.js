import { initTemplateGallery } from './ui/templateGallery.js';
import { generateGuidelines } from './controllers/exportController.js';

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initialize 8 Templates in Gallery
    initTemplateGallery();

    // 2. Bind Generate Button
    const generateBtn = document.getElementById('generateBtn');
    generateBtn.addEventListener('click', async () => {
        try {
            generateBtn.innerText = "Generating...";
            await generateGuidelines();
            generateBtn.innerText = "Success!";
            setTimeout(() => { generateBtn.innerText = "Generate Brand Guidelines"; }, 2000);
        } catch (error) {
            console.error("Export Failed", error);
            generateBtn.innerText = "Error - Try Again";
        }
    });
});