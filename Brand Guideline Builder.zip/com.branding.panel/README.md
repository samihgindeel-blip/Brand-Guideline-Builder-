# Brand Guidelines Generator (Adobe Illustrator panel)

Add your **logos** (full logo, logo mark, logotype), your **colors** and optional **fonts**, pick one of the
**templates** in `templates/`, and click **Generate Guidelines**. The panel copies that template and fills
every page with your brand in a few seconds. Your original templates are never modified.

Output: `Documents\Brand Guidelines\<Brand> - <Template> Guidelines.ai` (opened in Illustrator), plus
optional **Export PDF** / **Export PNG pages**.

## Install (Windows), signed ZXP (recommended)

The panel is signed as `dist\BrandGuidelinesGenerator.zxp` with a self-signed certificate (`_signing\`).
A signed panel loads without debug mode. To rebuild, re-sign and install after changing files:

```powershell
powershell -ExecutionPolicy Bypass -File G:\com.branding.panel\build-zxp.ps1 -ZXPSignCmd "C:\path\to\ZXPSignCmd.exe" -Install
```

This unpacks the ZXP into `%APPDATA%\Adobe\CEP\extensions\com.branding.panel`. Keep `_signing\` private, and
make sure no other copy with the same id exists in `Program Files (x86)\Common Files\Adobe\CEP\extensions`.
To share the plugin, send the `.zxp`; people install it with Adobe's UPIA or a tool like ZXPInstaller.

## Install (Windows), development mode (unsigned)

```powershell
powershell -ExecutionPolicy Bypass -File G:\com.branding.panel\install.ps1
```

The installer:
1. Turns on `PlayerDebugMode`, which lets Illustrator load unsigned extensions. **Without it the panel is an empty grey box.**
2. Offers to delete an old copied install in `Program Files (x86)\Common Files\Adobe\CEP\extensions`.
3. Links this folder into `%APPDATA%\Adobe\CEP\extensions`, so edits here apply to the panel directly.

Then **fully quit Illustrator** (File → Exit), reopen it and choose **Window → Extensions (Legacy) → Brand Guidelines Generator**.
On first open the panel renders a preview of each template into `templates/<folder>/thumbs/`.

To give the plugin to other people, sign it as a `.zxp` with Adobe's ZXPSignCmd. They then won't need debug mode.

## How templates work

Each folder in `templates/` holds one or more `.ai` files plus a `config.json` that names them:

```json
{
  "name": "Corporate",
  "order": 1,
  "variants": [
    { "file": "template.ai", "name": "Corporate", "pages": 40, "order": 1, "description": "40-page corporate brandbook" }
  ]
}
```

Any `.ai` dropped into a folder shows up in the panel, even without a `variants` entry.
Inside the `.ai`, objects are tagged by **name** (Layers panel):

| Tag (object name) | What the plugin does |
|---|---|
| `logomark`, `logotype`, `fulllogo` | Placeholder box replaced by that logo, fitted inside it |
| `…\|white`, `…\|black` | One-color version; white details knock out to the background color |
| `…\|fh`, `…\|fv`, `…\|s`, `…\|sh`, `…\|r1` | Misuse examples: flip H, flip V, stretch, skew, rotate |
| `primary`, `secondary`, `tertiary`, `additional1`–`3` | Fill (or stroke) set to that brand color. Groups are recolored inside |
| `headerfont`, `subheaderfont`, `bodyfont` (text) | Font family applied, keeping each paragraph's weight. Text that no longer fits is shrunk |
| `generatedate` (text) | Current year |
| `pagenumber` (text) | Number of the artboard it sits on |
| Layer `Delete` | Removed (template helper notes) |

Text tokens replaced anywhere: `{{brandname}}`, `{{headerfont}}`, `{{subheaderfont}}`, `{{bodyfont}}`,
`{{primaryhex}}`, `{{primaryrgb}}`, `{{primarycmyk}}`, and the same for `secondary`, `tertiary`, `additional1`–`3`.

Brand colors are added as **global swatches** in a "<Brand> Brand Colors" group. Edit one swatch and every page updates.
Roles you leave unticked are derived from your primary and secondary colors.

## Project layout

```
CSXS/manifest.xml   CEP extension manifest (Illustrator 24+)
index.html          Panel UI
css/panel.css       Panel styles
js/main.js          Panel logic, talks to Illustrator via evalScript
jsx/host.jsx        ExtendScript engine: copies the template, fills the tags, exports
templates/*/        Your .ai templates + config.json + generated thumbs/
install.ps1         Local install helper (Windows)
_legacy/            Old unfinished UXP files, kept for reference only
```

ExtendScript is ES3 and mis-parses chained ternaries (`a ? b : c ? d : e`), so `host.jsx` always uses `if/else`.
