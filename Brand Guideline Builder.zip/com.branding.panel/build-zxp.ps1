# Builds, signs and installs the panel as a signed ZXP (no PlayerDebugMode needed).
#   powershell -ExecutionPolicy Bypass -File .\build-zxp.ps1 -ZXPSignCmd "C:\path\to\ZXPSignCmd.exe" [-Install]
# ZXPSignCmd: https://github.com/Adobe-CEP/CEP-Resources/tree/master/ZXPSignCMD (4.1.103/win64)
# Signing material: _signing\cert.p12 + _signing\cert-password.txt (created on first run).
param(
    [Parameter(Mandatory = $true)][string]$ZXPSignCmd,
    [switch]$Install
)
$ErrorActionPreference = "Stop"
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
$stage = Join-Path $env:TEMP "bgg-zxp-stage\com.branding.panel"
if (Test-Path (Split-Path $stage)) { Remove-Item (Split-Path $stage) -Recurse -Force }
New-Item -ItemType Directory -Force $stage | Out-Null
foreach ($p in "CSXS", "css", "js", "jsx", "templates") { Copy-Item (Join-Path $src $p) (Join-Path $stage $p) -Recurse }
Copy-Item (Join-Path $src "index.html") $stage

$sign = Join-Path $src "_signing"
New-Item -ItemType Directory -Force $sign | Out-Null
$cert = Join-Path $sign "cert.p12"; $pwFile = Join-Path $sign "cert-password.txt"
if (-not (Test-Path $cert)) {
    $pw = -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 24 | ForEach-Object { [char]$_ })
    Set-Content $pwFile $pw -Encoding ascii -NoNewline
    & $ZXPSignCmd -selfSignedCert XX NA "Brand Guidelines Generator" "Brand Guidelines Generator" $pw $cert -validityDays 3650
}
$pw = Get-Content $pwFile -Raw

$dist = Join-Path $src "dist"; New-Item -ItemType Directory -Force $dist | Out-Null
$zxp = Join-Path $dist "BrandGuidelinesGenerator.zxp"
if (Test-Path $zxp) { Remove-Item $zxp }
# Note: -tsa (timestamping) crashes ZXPSignCmd 4.1.103, so the ZXP is signed without a timestamp (valid until the cert expires).
& $ZXPSignCmd -sign $stage $zxp $cert $pw
& $ZXPSignCmd -verify $zxp
Write-Host "Built $zxp"

if ($Install) {
    $dest = Join-Path $env:APPDATA "Adobe\CEP\extensions\com.brandguide.builder"
    if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
    # remove the earlier signed install that used the old extension id
    $oldDest = Join-Path $env:APPDATA "Adobe\CEP\extensions\com.branding.panel"
    if (Test-Path (Join-Path $oldDest "META-INF\signatures.xml")) { Remove-Item $oldDest -Recurse -Force }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::ExtractToDirectory($zxp, $dest)
    Write-Host "Installed to $dest. Restart Illustrator."
}
