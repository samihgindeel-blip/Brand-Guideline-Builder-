# Installs the Brand Guidelines Generator panel for local use in Illustrator (Windows).
#  1. Enables unsigned CEP extensions (PlayerDebugMode=1) for CSXS 9-13 in HKCU.
#     Without this, Illustrator shows the panel as an EMPTY grey box.
#  2. Removes an old copied install in Program Files (same extension id would clash).
#  3. Links this folder into %APPDATA%\Adobe\CEP\extensions\com.branding.panel
# Then restart Illustrator and open Window > Extensions (Legacy) > Brand Guidelines Generator.

$ErrorActionPreference = "Stop"
$src = Split-Path -Parent $MyInvocation.MyCommand.Path

foreach ($v in 9..13) {
    $key = "HKCU:\Software\Adobe\CSXS.$v"
    if (-not (Test-Path $key)) { New-Item -Path $key -Force | Out-Null }
    Set-ItemProperty -Path $key -Name PlayerDebugMode -Value "1" -Type String
}
Write-Host "PlayerDebugMode enabled for CSXS.9 - CSXS.13"

foreach ($old in @("${env:ProgramFiles(x86)}\Common Files\Adobe\CEP\extensions\com.branding.panel",
                   "$env:ProgramFiles\Common Files\Adobe\CEP\extensions\com.branding.panel")) {
    if ((Test-Path $old) -and ((Resolve-Path $old).Path -ne (Resolve-Path $src).Path)) {
        $answer = Read-Host "Old copy found at '$old'. It conflicts with this install. Delete it? (y/n)"
        if ($answer -eq "y") {
            try { Remove-Item $old -Recurse -Force; Write-Host "Removed $old" }
            catch { Write-Warning "Could not remove $old (run PowerShell as Administrator, or delete it in Explorer)." }
        } else {
            Write-Warning "Left $old in place. Illustrator may load that old copy instead of this folder."
        }
    }
}

$extRoot = Join-Path $env:APPDATA "Adobe\CEP\extensions"
New-Item -ItemType Directory -Force $extRoot | Out-Null
$dest = Join-Path $extRoot "com.branding.panel"
if (Test-Path $dest) {
    $item = Get-Item $dest -Force
    if ($item.LinkType) { Remove-Item $dest -Force }
    else { throw "$dest already exists and is a real folder. Remove it manually first." }
}
# A junction needs no admin rights and keeps the panel in sync with this folder.
New-Item -ItemType Junction -Path $dest -Target $src | Out-Null
Write-Host "Linked $dest -> $src"
Write-Host ""
Write-Host "Done. Fully quit and restart Illustrator, then open Window > Extensions (Legacy) > Brand Guidelines Generator."
