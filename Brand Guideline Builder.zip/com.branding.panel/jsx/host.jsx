/*
 * Brand Guidelines Generator - Illustrator host script (ExtendScript / ES3).
 *
 * Fills the tagged .ai templates in /templates with the user's brand:
 *   Logo placeholders  : items named  logomark | logotype | fulllogo  (+ modifiers  |white |black |fh |fv |s |sh |r1)
 *   Color tags         : items named  primary | secondary | tertiary | additional1..3   (fills / strokes recolored)
 *   Font tags          : text frames named  headerfont | subheaderfont | bodyfont
 *   Text tokens        : {{brandname}} {{headerfont}} {{subheaderfont}} {{bodyfont}} {{<role>hex}} {{<role>rgb}} {{<role>cmyk}}
 *   Auto text          : generatedate (year), pagenumber (artboard number)
 *   Layer "Delete"     : removed (template helper notes)
 *
 * Entry points (called from js/main.js), each returning a JSON string {"ok":true,"data":...} | {"ok":false,"error":"..."}
 *   BG_ping, BG_listTemplates, BG_buildThumbnails, BG_pickLogo, BG_captureSelection,
 *   BG_colorsFromSelection, BG_generate, BG_exportPDF, BG_exportPNG
 *
 * NOTE: ExtendScript mis-parses chained ternaries (a ? b : c ? d : e). Use if/else.
 */

var BG = {};
BG.ROOT = (function () { try { return File($.fileName).parent.parent.fsName; } catch (e) { return ""; } })();
BG.TMP = Folder.userData.fsName + "/BrandGuidelinesGenerator";
BG.ROLES = ["primary", "secondary", "tertiary", "additional1", "additional2", "additional3"];
BG.ROLE_LABELS = { primary: "Primary", secondary: "Secondary", tertiary: "Tertiary", additional1: "Additional 1", additional2: "Additional 2", additional3: "Additional 3" };
BG.TAG_ALIASES = { teriary: "tertiary" };

/* ------------------------------------------------------------------ */
/* JSON / misc helpers                                                 */
/* ------------------------------------------------------------------ */
BG.quote = function (s) {
    return '"' + String(s)
        .replace(/\\/g, "\\\\").replace(/"/g, '\\"')
        .replace(/\r/g, "\\r").replace(/\n/g, "\\n").replace(/\t/g, "\\t") + '"';
};
BG.stringify = function (v) {
    var t = typeof v, i, out;
    if (v === null || v === undefined) return "null";
    if (t === "number") return isFinite(v) ? String(v) : "null";
    if (t === "boolean") return v ? "true" : "false";
    if (t === "string") return BG.quote(v);
    if (v instanceof Array) {
        out = [];
        for (i = 0; i < v.length; i++) out.push(BG.stringify(v[i]));
        return "[" + out.join(",") + "]";
    }
    if (t === "object") {
        out = [];
        for (var k in v) { if (v.hasOwnProperty(k)) out.push(BG.quote(k) + ":" + BG.stringify(v[k])); }
        return "{" + out.join(",") + "}";
    }
    return "null";
};
BG.parse = function (s) { return eval("(" + String(s).replace(/^﻿/, "") + ")"); };
BG.ok = function (data) { return BG.stringify({ ok: true, data: data === undefined ? null : data }); };
BG.fail = function (e) {
    var msg = (e && e.message) ? e.message : String(e);
    if (e && e.line) msg += " (host.jsx line " + e.line + ")";
    return BG.stringify({ ok: false, error: msg });
};
BG.readText = function (path) {
    var f = new File(path);
    if (!f.exists) return null;
    f.encoding = "UTF-8";
    f.open("r");
    var t = f.read();
    f.close();
    return t;
};
BG.ensureFolder = function (path) {
    var f = new Folder(path);
    if (!f.exists) f.create();
    return f;
};
BG.ensureTmp = function () { return BG.ensureFolder(BG.TMP); };
BG.pad = function (n) { return n < 10 ? "0" + n : String(n); };
BG.trim = function (s) { return String(s).replace(/^\s+|\s+$/g, ""); };
BG.isVectorPath = function (p) { return /\.(ai|eps|svg|pdf)$/i.test(p); };
BG.withQuietUI = function (fn) {
    var uil = app.userInteractionLevel;
    app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
    try { return fn(); } finally { app.userInteractionLevel = uil; }
};

/* ------------------------------------------------------------------ */
/* Colors                                                              */
/* ------------------------------------------------------------------ */
BG.hexToRgb = function (hex) {
    hex = String(hex).replace("#", "");
    if (hex.length === 3) hex = hex.charAt(0) + hex.charAt(0) + hex.charAt(1) + hex.charAt(1) + hex.charAt(2) + hex.charAt(2);
    var n = parseInt(hex, 16);
    if (isNaN(n)) n = 0;
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
};
BG.rgbToHex = function (r, g, b) {
    function h(v) { v = Math.max(0, Math.min(255, Math.round(v))); var s = v.toString(16); return s.length < 2 ? "0" + s : s; }
    return ("#" + h(r) + h(g) + h(b)).toUpperCase();
};
BG.mix = function (hexA, hexB, t) {
    var a = BG.hexToRgb(hexA), b = BG.hexToRgb(hexB);
    return BG.rgbToHex(a.r + (b.r - a.r) * t, a.g + (b.g - a.g) * t, a.b + (b.b - a.b) * t);
};
BG.rgbColor = function (hex) {
    var o = BG.hexToRgb(hex), c = new RGBColor();
    c.red = o.r; c.green = o.g; c.blue = o.b;
    return c;
};
BG.toCmyk = function (o) {
    try {
        var v = app.convertSampleColor(ImageColorSpace.RGB, [o.r, o.g, o.b], ImageColorSpace.CMYK, ColorConvertPurpose.defaultpurpose);
        return [Math.round(v[0]), Math.round(v[1]), Math.round(v[2]), Math.round(v[3])];
    } catch (e) {
        var r = o.r / 255, g = o.g / 255, b = o.b / 255, k = 1 - Math.max(r, g, b);
        if (k >= 1) return [0, 0, 0, 100];
        return [Math.round((1 - r - k) / (1 - k) * 100), Math.round((1 - g - k) / (1 - k) * 100), Math.round((1 - b - k) / (1 - k) * 100), Math.round(k * 100)];
    }
};
BG.colorToRgb = function (c) {
    if (!c) return null;
    switch (c.typename) {
        case "RGBColor": return { r: c.red, g: c.green, b: c.blue };
        case "GrayColor": var v = 255 * (1 - c.gray / 100); return { r: v, g: v, b: v };
        case "CMYKColor":
            var k = c.black / 100;
            return { r: 255 * (1 - c.cyan / 100) * (1 - k), g: 255 * (1 - c.magenta / 100) * (1 - k), b: 255 * (1 - c.yellow / 100) * (1 - k) };
        case "SpotColor":
            var base = BG.colorToRgb(c.spot.color);
            if (!base) return null;
            var t = (c.tint === undefined ? 100 : c.tint) / 100;
            return { r: 255 - (255 - base.r) * t, g: 255 - (255 - base.g) * t, b: 255 - (255 - base.b) * t };
        default: return null;
    }
};
BG.isWhiteish = function (c) {
    var o = BG.colorToRgb(c);
    return !!o && o.r > 242 && o.g > 242 && o.b > 242;
};

/* Fills in any missing roles so every tagged color gets a sensible value. */
BG.completePalette = function (colors) {
    var p = {}, i;
    for (i = 0; i < colors.length; i++) {
        var role = colors[i].role || BG.ROLES[i];
        if (colors[i].hex) p[role] = String(colors[i].hex).toUpperCase();
    }
    if (!p.primary) p.primary = "#316CFF";
    if (!p.secondary) p.secondary = BG.mix(p.primary, "#000000", 0.45);
    if (!p.tertiary) p.tertiary = BG.mix(p.secondary, "#000000", 0.5);
    if (!p.additional1) p.additional1 = BG.mix(p.primary, "#FFFFFF", 0.55);
    if (!p.additional2) p.additional2 = BG.mix(p.secondary, "#FFFFFF", 0.55);
    if (!p.additional3) p.additional3 = BG.mix(p.primary, p.secondary, 0.5);
    return p;
};

/* ------------------------------------------------------------------ */
/* Fonts                                                               */
/* ------------------------------------------------------------------ */
BG.fontIndex = null;
BG.norm = function (s) { return String(s).toLowerCase().replace(/[\s\-_]+/g, ""); };
BG.buildFontIndex = function () {
    var idx = { byName: {}, byFamily: {} };
    var n = app.textFonts.length;
    for (var i = 0; i < n; i++) {
        var f = app.textFonts[i];
        idx.byName[BG.norm(f.name)] = f;
        var fam = BG.norm(f.family);
        if (!idx.byFamily[fam]) idx.byFamily[fam] = {};
        idx.byFamily[fam][BG.norm(f.style)] = f;
    }
    BG.fontIndex = idx;
};
/* Installed family lookup (by family name or PostScript name). Returns {family: {style: font}} or null. */
BG.findFamily = function (want) {
    if (!want) return null;
    if (!BG.fontIndex) BG.buildFontIndex();
    var key = BG.norm(want);
    if (BG.fontIndex.byFamily[key]) return BG.fontIndex.byFamily[key];
    var exact = BG.fontIndex.byName[key];
    if (exact) return BG.fontIndex.byFamily[BG.norm(exact.family)];
    var dash = String(want).indexOf("-");
    if (dash > 0) return BG.fontIndex.byFamily[BG.norm(String(want).substring(0, dash))] || null;
    return null;
};
/* Picks the font of `family` closest to `style` (e.g. "Bold", "Regular", "Bold Italic"). */
BG.pickStyle = function (fam, style) {
    if (!fam) return null;
    var s = BG.norm(style || "regular");
    if (fam[s]) return fam[s];
    var italic = s.indexOf("italic") >= 0 || s.indexOf("oblique") >= 0;
    var bold = /bold|black|heavy|semi|demi|extra/.test(s);
    var prefs;
    if (bold) prefs = ["bold", "semibold", "extrabold", "black", "heavy", "medium"];
    else prefs = ["regular", "roman", "book", "normal", "medium", "light"];
    var i;
    if (italic) { for (i = 0; i < prefs.length; i++) if (fam[prefs[i] + "italic"]) return fam[prefs[i] + "italic"]; if (fam.italic) return fam.italic; }
    for (i = 0; i < prefs.length; i++) if (fam[prefs[i]]) return fam[prefs[i]];
    for (var k in fam) if (fam.hasOwnProperty(k)) return fam[k];
    return null;
};
BG.familyLabel = function (fam) {
    for (var k in fam) if (fam.hasOwnProperty(k)) return String(fam[k].family);
    return "";
};

/* ------------------------------------------------------------------ */
/* Art import / geometry                                               */
/* ------------------------------------------------------------------ */
BG.importArt = function (container, path) {
    var f = new File(path);
    if (!f.exists) throw new Error("Logo file not found: " + path);
    if (BG.isVectorPath(path)) {
        try { return container.groupItems.createFromFile(f); } catch (e1) { }
    }
    var p = container.placedItems.add();
    p.file = f;
    try { p.embed(); } catch (e2) { return p; }
    return container.pageItems[0];
};
BG.bounds = function (it) {
    try {
        if (it.typename === "GroupItem" && it.clipped) {
            for (var i = 0; i < it.pageItems.length; i++) {
                var c = it.pageItems[i];
                if ((c.typename === "PathItem" && c.clipping) || (c.typename === "CompoundPathItem" && c.pathItems.length && c.pathItems[0].clipping)) return c.geometricBounds;
            }
        }
    } catch (e) { }
    return it.visibleBounds;
};
/* Uniformly scales `it` to fit inside bounds [l,t,r,b] and centers it. */
BG.fitToBounds = function (it, box) {
    var bw = box[2] - box[0], bh = box[1] - box[3];
    var b = BG.bounds(it), iw = b[2] - b[0], ih = b[1] - b[3];
    if (iw <= 0 || ih <= 0 || bw <= 0 || bh <= 0) return it;
    var s = Math.min(bw / iw, bh / ih) * 100;
    it.resize(s, s, true, true, true, true, s);
    b = BG.bounds(it); iw = b[2] - b[0]; ih = b[1] - b[3];
    it.translate(box[0] + (bw - iw) / 2 - b[0], box[1] - (bh - ih) / 2 - b[1]);
    return it;
};
BG.countVector = function (it) {
    var t = it.typename, n = 0, i;
    if (t === "GroupItem") { for (i = 0; i < it.pageItems.length; i++) n += BG.countVector(it.pageItems[i]); }
    else if (t === "CompoundPathItem" || t === "PathItem" || t === "TextFrame") n = 1;
    return n;
};
BG.countNonWhite = function (it) {
    var t = it.typename, n = 0, i;
    if (t === "GroupItem") { for (i = 0; i < it.pageItems.length; i++) n += BG.countNonWhite(it.pageItems[i]); }
    else if (t === "CompoundPathItem") { if (it.pathItems.length && !(it.pathItems[0].filled && BG.isWhiteish(it.pathItems[0].fillColor))) n = 1; }
    else if (t === "PathItem") { if (!it.clipping && ((it.filled && !BG.isWhiteish(it.fillColor)) || (it.stroked && !BG.isWhiteish(it.strokeColor)))) n = 1; }
    else if (t === "TextFrame") n = 1;
    return n;
};
/* Finds the fill color of the smallest filled shape behind `box` (used to "knock out" white logo details). */
BG.bgCandidates = null;
BG.collectBackgrounds = function (doc) {
    var list = [], skip = { "Logomark": 1, "Logotype": 1, "Full Logo": 1, "_logo sources": 1 };
    for (var i = 0; i < doc.pathItems.length; i++) {
        var p = doc.pathItems[i];
        try {
            if (!p.filled || p.clipping || p.hidden || skip[p.layer.name]) continue;
            if (/^(logomark|logotype|fulllogo)/i.test(BG.trim(p.name))) continue; // other logo placeholders are not backgrounds
            var t = p.fillColor.typename;
            if (t !== "RGBColor" && t !== "SpotColor" && t !== "GrayColor" && t !== "CMYKColor") continue;
            if (p.opacity < 99) continue;
            var b = p.geometricBounds;
            list.push({ b: b, area: (b[2] - b[0]) * (b[1] - b[3]), color: p.fillColor });
        } catch (e) { }
    }
    BG.bgCandidates = list;
};
BG.backgroundUnder = function (box) {
    if (!BG.bgCandidates) return null;
    var cx = (box[0] + box[2]) / 2, cy = (box[1] + box[3]) / 2, minArea = (box[2] - box[0]) * (box[1] - box[3]);
    var best = null;
    for (var i = 0; i < BG.bgCandidates.length; i++) {
        var c = BG.bgCandidates[i], b = c.b;
        if (cx < b[0] || cx > b[2] || cy > b[1] || cy < b[3]) continue;
        if (c.area < minArea) continue;
        if (!best || c.area < best.area) best = c;
    }
    return best ? best.color : null;
};

/* One-color version of a logo. White details get `knockout` (the background color) when known,
   otherwise they are removed so the background shows through. Everything else gets `color`. */
BG.monoize = function (it, color, knockout) {
    var removeWhite = BG.countNonWhite(it) > 0, trash = [];
    function walk(x) {
        var t = x.typename, i;
        if (t === "GroupItem") { for (i = 0; i < x.pageItems.length; i++) walk(x.pageItems[i]); }
        else if (t === "CompoundPathItem") { for (i = 0; i < x.pathItems.length; i++) { var p = x.pathItems[i]; if (p.filled) p.fillColor = color; if (p.stroked) p.strokeColor = color; } }
        else if (t === "PathItem") {
            if (x.clipping) return;
            var wf = x.filled && BG.isWhiteish(x.fillColor), ws = x.stroked && BG.isWhiteish(x.strokeColor);
            if (removeWhite && (wf || !x.filled) && (ws || !x.stroked) && (x.filled || x.stroked)) {
                if (knockout) { if (x.filled) x.fillColor = knockout; if (x.stroked) x.strokeColor = knockout; }
                else trash.push(x);
                return;
            }
            if (x.filled) x.fillColor = color;
            if (x.stroked) x.strokeColor = color;
        } else if (t === "TextFrame") { try { x.textRange.characterAttributes.fillColor = color; } catch (e) { } }
    }
    walk(it);
    for (var j = 0; j < trash.length; j++) { try { trash[j].remove(); } catch (e2) { } }
};
/* Paints a color-tagged item. Gradient fills are left alone. */
BG.paint = function (it, color) {
    var t = it.typename, i;
    if (t === "GroupItem") { for (i = 0; i < it.pageItems.length; i++) BG.paint(it.pageItems[i], color); }
    else if (t === "CompoundPathItem") { for (i = 0; i < it.pathItems.length; i++) BG.paint(it.pathItems[i], color); }
    else if (t === "PathItem") {
        if (it.clipping) return;
        if (it.filled) { if (it.fillColor.typename !== "GradientColor") it.fillColor = color; }
        else if (it.stroked) { if (it.strokeColor.typename !== "GradientColor") it.strokeColor = color; }
        else { it.filled = true; it.fillColor = color; }
    } else if (t === "TextFrame") {
        try { it.textRange.characterAttributes.fillColor = color; } catch (e) { }
    }
};

/* ------------------------------------------------------------------ */
/* Text                                                                */
/* ------------------------------------------------------------------ */
BG.forceWesternDigits = function (tf) {
    try { tf.textRange.characterAttributes.digitSet = DigitSetType.ARABIC_DIGITS; } catch (e) { }
};
/* Replaces every occurrence of `token` keeping the formatting of the surrounding text. */
BG.replaceToken = function (tf, token, value) {
    value = String(value);
    var guard = 0;
    while (guard++ < 30) {
        var before = String(tf.contents), idx = before.indexOf(token);
        if (idx < 0) return;
        var expected = before.substring(0, idx) + value + before.substring(idx + token.length);
        var okFast = false;
        try {
            if (value.length > 0) {
                tf.characters[idx].contents = value;
                for (var k = token.length - 2; k >= 0; k--) tf.characters[idx + value.length + k].remove();
            } else {
                for (var k2 = token.length - 1; k2 >= 0; k2--) tf.characters[idx + k2].remove();
            }
            okFast = String(tf.contents) === expected;
        } catch (e) { okFast = false; }
        if (!okFast) tf.contents = expected; // fallback: plain replacement
    }
};
/* Applies a font family to a text frame, keeping each paragraph's weight/style. */
BG.applyFamily = function (tf, fam) {
    if (!fam) return;
    var paras = null;
    try { paras = tf.paragraphs; } catch (e) { paras = null; }
    var n = paras ? paras.length : 0;
    if (n === 0) {
        try { var f0 = BG.pickStyle(fam, tf.textRange.characterAttributes.textFont.style); if (f0) tf.textRange.characterAttributes.textFont = f0; } catch (e0) { }
        return;
    }
    for (var i = 0; i < n; i++) {
        try {
            var p = paras[i];
            if (!p.characters.length) continue;
            var cur = p.characters[0].characterAttributes.textFont;
            var f = BG.pickStyle(fam, cur.style);
            if (f && f.name !== cur.name) p.characterAttributes.textFont = f;
        } catch (e1) { }
    }
};

/* Area text that no longer fits (e.g. a wider font) is shrunk in 5% steps until all text is visible. */
BG.visibleChars = function (tf) {
    var n = 0, L = tf.lines;
    for (var i = 0; i < L.length; i++) n += String(L[i].contents).replace(/[\r\n\u0003]/g, "").length;
    return n;
};
BG.fixOverflow = function (tf) {
    try {
        if (tf.kind !== TextType.AREATEXT) return false;
        var total = String(tf.contents).replace(/[\r\n\u0003]/g, "").length;
        if (!total || BG.visibleChars(tf) >= total) return false;
        for (var step = 0; step < 10; step++) {
            var P = tf.paragraphs;
            for (var i = 0; i < P.length; i++) {
                if (!P[i].characters.length) continue;
                var ca = P[i].characters[0].characterAttributes;
                var sz = ca.size * 0.95, auto = ca.autoLeading, lead = ca.leading * 0.95;
                P[i].characterAttributes.size = sz;
                if (!auto) P[i].characterAttributes.leading = lead;
            }
            if (BG.visibleChars(tf) >= total) return true;
        }
    } catch (e) { }
    return false;
};

/* ------------------------------------------------------------------ */
/* Templates                                                           */
/* ------------------------------------------------------------------ */
BG.templatesRoot = function (root) { return (root || BG.ROOT) + "/templates"; };
BG.readConfig = function (folder) {
    var txt = BG.readText(folder + "/config.json");
    if (!txt) return {};
    try { return BG.parse(txt); } catch (e) { return {}; }
};
BG.listVariants = function (root) {
    var base = new Folder(BG.templatesRoot(root));
    if (!base.exists) throw new Error("templates folder not found at " + base.fsName);
    var dirs = base.getFiles(function (f) { return f instanceof Folder; }), out = [];
    for (var i = 0; i < dirs.length; i++) {
        var cfg = BG.readConfig(dirs[i].fsName);
        var files = dirs[i].getFiles(function (f) { return f instanceof File && /\.ai$/i.test(f.name); });
        var meta = {};
        if (cfg.variants) for (var v = 0; v < cfg.variants.length; v++) meta[cfg.variants[v].file] = cfg.variants[v];
        files.sort(function (a, b) {
            var oa = meta[decodeURI(a.name)] ? (meta[decodeURI(a.name)].order || 50) : 99, ob = meta[decodeURI(b.name)] ? (meta[decodeURI(b.name)].order || 50) : 99;
            return oa - ob;
        });
        for (var j = 0; j < files.length; j++) {
            var fname = decodeURI(files[j].name), m = meta[fname] || {};
            var thumb = new File(dirs[i].fsName + "/thumbs/" + fname.replace(/\.ai$/i, ".png"));
            var fallback = new File(dirs[i].fsName + "/thumbnail.png");
            out.push({
                id: dirs[i].name + "/" + fname,
                folder: dirs[i].name,
                file: fname,
                path: files[j].fsName,
                group: cfg.name || dirs[i].name,
                name: m.name || (cfg.name || dirs[i].name) + (j ? " " + (j + 1) : ""),
                description: m.description || cfg.description || "",
                pages: m.pages || 0,
                order: (cfg.order || 50) * 100 + j,
                thumbnail: thumb.exists ? thumb.fsName : (fallback.exists ? fallback.fsName : ""),
                hasThumb: thumb.exists
            });
        }
    }
    out.sort(function (a, b) { return a.order - b.order; });
    return out;
};
BG.findVariant = function (root, id) {
    var list = BG.listVariants(root);
    for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    if (list.length) return list[0];
    throw new Error("No .ai templates found in the templates folder.");
};

/* Walks all layers (and sublayers), unlocking + showing them; returns a restore function. */
BG.openUpLayers = function (doc) {
    var saved = [];
    function walk(L) {
        saved.push({ layer: L, locked: L.locked, visible: L.visible });
        try { L.locked = false; L.visible = true; } catch (e) { }
        for (var i = 0; i < L.layers.length; i++) walk(L.layers[i]);
    }
    for (var i = 0; i < doc.layers.length; i++) walk(doc.layers[i]);
    return function () {
        for (var j = saved.length - 1; j >= 0; j--) {
            try { saved[j].layer.visible = saved[j].visible; saved[j].layer.locked = saved[j].locked; } catch (e) { }
        }
    };
};

BG.uniqueFile = function (folder, base) {
    base = base.replace(/[\\\/:*?"<>|]+/g, "-");
    var f = new File(folder + "/" + base + ".ai"), n = 2;
    while (f.exists) { f = new File(folder + "/" + base + " (" + n + ").ai"); n++; }
    return f;
};

BG.applyTemplate = function (data) {
    var root = data.root || BG.ROOT;
    var variant = BG.findVariant(root, data.template);
    var brand = BG.trim(data.brand || "") || "Your Brand";
    var stats = { logos: 0, colors: 0, tokens: 0, fonts: 0, pages: 0, refit: 0, skipped: 0 };

    // 1. Copy the template so the original is never modified.
    var outFolder = BG.ensureFolder(data.outFolder || (Folder.myDocuments.fsName + "/Brand Guidelines"));
    var outFile = BG.uniqueFile(outFolder.fsName, brand + " - " + variant.name + " Guidelines");
    if (!new File(variant.path).copy(outFile.fsName)) throw new Error("Could not copy template to " + outFile.fsName);

    app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;
    var doc = app.open(outFile);
    var restoreLayers = BG.openUpLayers(doc);

    // 2. Remove helper layer.
    try { doc.layers.getByName("Delete").remove(); } catch (e0) { }

    // 3. Palette -> global swatches.
    var pal = BG.completePalette(data.colors || []);
    var swatch = {}, info = {}, group = null;
    try { group = doc.swatchGroups.add(); group.name = brand + " Brand Colors"; } catch (eg) { group = null; }
    for (var r = 0; r < BG.ROLES.length; r++) {
        var role = BG.ROLES[r], hex = pal[role], rgb = BG.hexToRgb(hex), fill;
        try {
            var spot = doc.spots.add();
            spot.name = brand + " " + BG.ROLE_LABELS[role];
            spot.colorType = ColorModel.PROCESS;
            spot.color = BG.rgbColor(hex);
            fill = new SpotColor(); fill.spot = spot; fill.tint = 100;
            if (group) { try { group.addSpot(spot); } catch (e1) { } }
        } catch (e2) { fill = BG.rgbColor(hex); }
        swatch[role] = fill;
        info[role] = { hex: hex, rgb: rgb.r + ", " + rgb.g + ", " + rgb.b, cmyk: BG.toCmyk(rgb).join(", ") };
    }

    // 4. Logo sources on a scratch layer.
    var srcLayer = doc.layers.add();
    srcLayer.name = "_logo sources";
    var art = {};
    var logos = data.logos || {};
    if (logos.fulllogo) art.fulllogo = BG.importArt(srcLayer, logos.fulllogo);
    if (logos.logomark) art.logomark = BG.importArt(srcLayer, logos.logomark);
    if (logos.logotype) art.logotype = BG.importArt(srcLayer, logos.logotype);
    var fallbacks = {
        fulllogo: ["fulllogo", "logotype", "logomark"],
        logotype: ["logotype", "fulllogo", "logomark"],
        logomark: ["logomark", "fulllogo", "logotype"]
    };
    function sourceFor(kind) {
        var list = fallbacks[kind];
        for (var i = 0; i < list.length; i++) if (art[list[i]]) return art[list[i]];
        return null;
    }
    var white = BG.rgbColor("#FFFFFF"), black = BG.rgbColor("#000000");

    // 5. Collect tagged items first (the collection changes while we edit).
    var logoTags = [], colorTags = [], textFrames = [];
    var all = doc.pageItems, n = all.length, i;
    for (i = 0; i < n; i++) {
        var it = all[i];
        var name = BG.trim(it.name).toLowerCase();
        if (!name) continue;
        if (it.layer && it.layer.name === "_logo sources") continue;
        var parts = name.split("|"), base = parts[0];
        if (BG.TAG_ALIASES[base]) base = BG.TAG_ALIASES[base];
        if (base === "logomark" || base === "logotype" || base === "fulllogo") logoTags.push({ item: it, kind: base, mods: parts.slice(1) });
        else if (swatch[base]) colorTags.push({ item: it, role: base });
    }
    for (i = 0; i < doc.textFrames.length; i++) textFrames.push(doc.textFrames[i]);

    // 6. Colors.
    for (i = 0; i < colorTags.length; i++) {
        try { BG.paint(colorTags[i].item, swatch[colorTags[i].role]); stats.colors++; } catch (e3) { stats.skipped++; }
    }

    // 7. Logos.
    BG.collectBackgrounds(doc);
    for (i = 0; i < logoTags.length; i++) {
        var tag = logoTags[i], ph = tag.item, src = sourceFor(tag.kind);
        if (!src) continue;
        try {
            var box = ph.geometricBounds;
            var dup = src.duplicate(ph, ElementPlacement.PLACEBEFORE);
            var mods = {};
            for (var m = 0; m < tag.mods.length; m++) mods[BG.trim(tag.mods[m])] = true;
            var vector = BG.countVector(dup) > 0;
            if (vector && (mods.white || mods.black)) {
                var under = BG.backgroundUnder(box);
                if (mods.white) BG.monoize(dup, white, under && !BG.isWhiteish(under) ? under : null);
                else BG.monoize(dup, black, under);
            }
            if (mods.sh) { var mx = app.getIdentityMatrix(); mx.mValueC = 0.36; dup.transform(mx); }
            if (mods.r1) dup.rotate(-15);
            BG.fitToBounds(dup, box);
            if (mods.fh) dup.resize(-100, 100);
            if (mods.fv) dup.resize(100, -100);
            if (mods.s) dup.resize(100, 55);
            dup.name = tag.kind + (tag.mods.length ? "|" + tag.mods.join("|") : "");
            ph.remove();
            stats.logos++;
        } catch (e4) { stats.skipped++; }
    }
    try { srcLayer.remove(); } catch (e5) { }
    BG.bgCandidates = null;

    // 8. Fonts.
    var fams = {
        headerfont: BG.findFamily(data.fonts && data.fonts.header),
        subheaderfont: BG.findFamily(data.fonts && data.fonts.subheader),
        bodyfont: BG.findFamily(data.fonts && data.fonts.body)
    };
    var fontNames = {};
    for (var role2 in fams) {
        if (!fams.hasOwnProperty(role2)) continue;
        if (fams[role2]) fontNames[role2] = BG.familyLabel(fams[role2]);
    }
    // default font names (when the user keeps the template fonts) come from the template's own tagged frames
    for (i = 0; i < textFrames.length; i++) {
        var tn = BG.trim(textFrames[i].name).toLowerCase();
        if ((tn === "headerfont" || tn === "subheaderfont" || tn === "bodyfont") && !fontNames[tn]) {
            try { fontNames[tn] = String(textFrames[i].textRange.characterAttributes.textFont.family); } catch (e6) { }
        }
    }

    // 9. Artboard lookup for page numbers.
    var abRects = [];
    for (i = 0; i < doc.artboards.length; i++) abRects.push(doc.artboards[i].artboardRect);
    function artboardOf(item) {
        var b = item.geometricBounds, cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2;
        for (var a = 0; a < abRects.length; a++) {
            var R = abRects[a];
            if (cx >= R[0] && cx <= R[2] && cy <= R[1] && cy >= R[3]) return a;
        }
        return -1;
    }

    var tokens = {
        "{{brandname}}": brand,
        "{{tagline}}": data.tagline || "",
        "{{headerfont}}": fontNames.headerfont || "",
        "{{subheaderfont}}": fontNames.subheaderfont || "",
        "{{bodyfont}}": fontNames.bodyfont || ""
    };
    for (r = 0; r < BG.ROLES.length; r++) {
        var ro = BG.ROLES[r];
        tokens["{{" + ro + "hex}}"] = info[ro].hex;
        tokens["{{" + ro + "rgb}}"] = info[ro].rgb;
        tokens["{{" + ro + "cmyk}}"] = info[ro].cmyk;
    }
    var year = String(new Date().getFullYear());

    for (i = 0; i < textFrames.length; i++) {
        var tf = textFrames[i];
        try {
            var tname = BG.trim(tf.name).toLowerCase();
            var contents = String(tf.contents), touched = false;
            if (contents.indexOf("{{") >= 0) {
                for (var tok in tokens) {
                    if (tokens.hasOwnProperty(tok) && contents.indexOf(tok) >= 0) { BG.replaceToken(tf, tok, tokens[tok]); stats.tokens++; touched = true; }
                }
            }
            if (tname === "generatedate") { tf.contents = year; touched = true; }
            else if (tname === "pagenumber") {
                var ab = artboardOf(tf);
                if (ab >= 0) { tf.contents = BG.pad(ab + 1); stats.pages++; touched = true; }
            }
            if (fams[tname]) { BG.applyFamily(tf, fams[tname]); stats.fonts++; }
            if (touched) BG.forceWesternDigits(tf);
            if (fams[tname] || touched) { if (BG.fixOverflow(tf)) stats.refit++; }
        } catch (e7) { stats.skipped++; }
    }

    restoreLayers();
    try { doc.artboards.setActiveArtboardIndex(0); app.executeMenuCommand("fitin"); } catch (e8) { }
    doc.save();
    return {
        file: outFile.fsName,
        template: variant.name,
        artboards: doc.artboards.length,
        logos: stats.logos, colors: stats.colors, tokens: stats.tokens, fonts: stats.fonts, pages: stats.pages, refit: stats.refit, skipped: stats.skipped,
        palette: pal
    };
};

/* ------------------------------------------------------------------ */
/* Preview / export helpers                                            */
/* ------------------------------------------------------------------ */
BG.exportArtboardPNG = function (doc, file, index, maxPx) {
    doc.artboards.setActiveArtboardIndex(index || 0);
    var r = doc.artboards[index || 0].artboardRect, w = r[2] - r[0], h = r[1] - r[3];
    var scale = 100;
    if (maxPx) scale = Math.min(400, 100 * maxPx / Math.max(w, h));
    var o = new ExportOptionsPNG24();
    o.artBoardClipping = true; o.transparency = false; o.antiAliasing = true;
    o.horizontalScale = scale; o.verticalScale = scale;
    doc.exportFile(file, ExportType.PNG24, o);
};
BG.makePreview = function (path) {
    var prev = app.documents.length ? app.activeDocument : null, tmp = null, out = null;
    try {
        tmp = app.documents.add(DocumentColorSpace.RGB, 600, 600);
        var it = BG.importArt(tmp.layers[0], path);
        tmp.artboards[0].artboardRect = BG.bounds(it);
        out = new File(BG.ensureTmp().fsName + "/preview_" + new Date().getTime() + ".png");
        var o = new ExportOptionsPNG24();
        o.artBoardClipping = true; o.transparency = true; o.antiAliasing = true;
        var r = tmp.artboards[0].artboardRect, s = Math.min(400, 100 * 360 / Math.max(r[2] - r[0], r[1] - r[3]));
        o.horizontalScale = s; o.verticalScale = s;
        tmp.exportFile(out, ExportType.PNG24, o);
    } catch (e) { out = null; }
    if (tmp) { try { tmp.close(SaveOptions.DONOTSAVECHANGES); } catch (e2) { } }
    if (prev) { try { prev.activate(); } catch (e3) { } }
    return out && out.exists ? out.fsName : "";
};

/* ------------------------------------------------------------------ */
/* Entry points                                                        */
/* ------------------------------------------------------------------ */
function BG_ping() { return BG.ok({ version: app.version, root: BG.ROOT }); }

function BG_listTemplates(root) {
    try { return BG.ok(BG.listVariants(root)); } catch (e) { return BG.fail(e); }
}

/* Renders the first artboard of each template to templates/<folder>/thumbs/<file>.png (only missing ones unless force). */
function BG_buildThumbnails(root, force) {
    try {
        var list = BG.listVariants(root), made = 0;
        BG.withQuietUI(function () {
            for (var i = 0; i < list.length; i++) {
                var v = list[i];
                if (v.hasThumb && !force) continue;
                var dir = BG.ensureFolder(BG.templatesRoot(root) + "/" + v.folder + "/thumbs");
                var doc = app.open(new File(v.path));
                try { BG.exportArtboardPNG(doc, new File(dir.fsName + "/" + v.file.replace(/\.ai$/i, ".png")), 0, 480); made++; }
                finally { doc.close(SaveOptions.DONOTSAVECHANGES); }
            }
        });
        return BG.ok({ made: made });
    } catch (e) { return BG.fail(e); }
}

function BG_pickLogo() {
    try {
        var filter = $.os.indexOf("Windows") >= 0
            ? "Logo files:*.ai;*.eps;*.svg;*.pdf;*.png;*.jpg;*.jpeg,All files:*.*"
            : function (f) { return f instanceof Folder || /\.(ai|eps|svg|pdf|png|jpe?g)$/i.test(f.name); };
        var f = File.openDialog("Choose a logo file (AI, EPS, SVG, PDF, PNG)", filter, false);
        if (!f) return BG.ok(null);
        var preview = f.fsName;
        if (!/\.(png|jpe?g|svg)$/i.test(f.name)) preview = BG.withQuietUI(function () { return BG.makePreview(f.fsName); });
        return BG.ok({ path: f.fsName, name: decodeURI(f.name), preview: preview, vector: BG.isVectorPath(f.fsName) });
    } catch (e) { return BG.fail(e); }
}

function BG_captureSelection() {
    try {
        if (!app.documents.length) throw new Error("Open a document and select your logo artwork first.");
        var src = app.activeDocument, sel = src.selection;
        if (!sel || !sel.length || sel.typename === "TextRange") throw new Error("Select the logo artwork with the Selection tool (V), then click \"Use selection\".");
        var items = [];
        for (var i = 0; i < sel.length; i++) items.push(sel[i]);
        return BG.withQuietUI(function () {
            var tmp = app.documents.add(DocumentColorSpace.RGB, 1000, 1000);
            var grp = tmp.layers[0].groupItems.add();
            for (var j = 0; j < items.length; j++) items[j].duplicate(grp, ElementPlacement.PLACEATEND);
            tmp.artboards[0].artboardRect = BG.bounds(grp);
            var stamp = new Date().getTime();
            var aiFile = new File(BG.ensureTmp().fsName + "/selection_" + stamp + ".ai");
            var png = new File(BG.ensureTmp().fsName + "/selection_" + stamp + ".png");
            var o = new ExportOptionsPNG24();
            o.artBoardClipping = true; o.transparency = true; o.antiAliasing = true;
            var r = tmp.artboards[0].artboardRect, s = Math.min(400, 100 * 360 / Math.max(r[2] - r[0], r[1] - r[3]));
            o.horizontalScale = s; o.verticalScale = s;
            tmp.exportFile(png, ExportType.PNG24, o);
            tmp.saveAs(aiFile, new IllustratorSaveOptions());
            tmp.close(SaveOptions.DONOTSAVECHANGES);
            try { src.activate(); } catch (e2) { }
            return BG.ok({ path: aiFile.fsName, name: "Selection (" + items.length + " object" + (items.length > 1 ? "s" : "") + ")", preview: png.exists ? png.fsName : "", vector: true });
        });
    } catch (e) { return BG.fail(e); }
}

function BG_colorsFromSelection() {
    try {
        if (!app.documents.length) throw new Error("Open a document and select artwork first.");
        var sel = app.activeDocument.selection, found = {}, list = [];
        if (!sel || !sel.length || sel.typename === "TextRange") throw new Error("Select artwork that uses your brand colors.");
        function add(c) {
            var o = BG.colorToRgb(c);
            if (!o) return;
            var hex = BG.rgbToHex(o.r, o.g, o.b);
            if (!found[hex] && list.length < 6) { found[hex] = true; list.push(hex); }
        }
        function walk(it) {
            var t = it.typename, i;
            if (t === "GroupItem") { for (i = 0; i < it.pageItems.length; i++) walk(it.pageItems[i]); }
            else if (t === "CompoundPathItem") { for (i = 0; i < it.pathItems.length; i++) walk(it.pathItems[i]); }
            else if (t === "PathItem") { if (it.filled) add(it.fillColor); if (it.stroked) add(it.strokeColor); }
            else if (t === "TextFrame") { try { add(it.textRange.characterAttributes.fillColor); } catch (e) { } }
        }
        for (var i = 0; i < sel.length; i++) walk(sel[i]);
        return BG.ok(list);
    } catch (e) { return BG.fail(e); }
}

function BG_generate(payload) {
    try {
        var data = typeof payload === "string" ? BG.parse(payload) : payload;
        var L = data.logos || {};
        if (!L.fulllogo && !L.logomark && !L.logotype) throw new Error("Add at least one logo (full logo, logo mark or logotype).");
        var result = BG.withQuietUI(function () { return BG.applyTemplate(data); });
        return BG.ok(result);
    } catch (e) { return BG.fail(e); }
}

function BG_exportPDF() {
    try {
        if (!app.documents.length) throw new Error("No open document to export.");
        var doc = app.activeDocument;
        var f = File.saveDialog("Save brand guidelines as PDF", $.os.indexOf("Windows") >= 0 ? "PDF:*.pdf" : undefined);
        if (!f) return BG.ok(null);
        if (!/\.pdf$/i.test(f.name)) f = new File(f.fsName + ".pdf");
        var o = new PDFSaveOptions();
        o.compatibility = PDFCompatibility.ACROBAT7;
        o.preserveEditability = false;
        o.generateThumbnails = true;
        o.viewAfterSaving = false;
        // Save a PDF copy, then reopen the .ai so the user keeps working on the editable file.
        var aiPath = null;
        try { if (doc.path && String(doc.path) !== "") aiPath = doc.fullName; } catch (e0) { aiPath = null; }
        if (aiPath) doc.save();
        doc.saveAs(f, o);
        if (aiPath) { doc.close(SaveOptions.DONOTSAVECHANGES); app.open(aiPath); }
        return BG.ok({ file: f.fsName });
    } catch (e) { return BG.fail(e); }
}

function BG_exportPNG() {
    try {
        if (!app.documents.length) throw new Error("No open document to export.");
        var doc = app.activeDocument;
        var folder = Folder.selectDialog("Choose a folder for the PNG pages");
        if (!folder) return BG.ok(null);
        var n = doc.artboards.length;
        BG.withQuietUI(function () {
            for (var i = 0; i < n; i++) {
                var name = BG.pad(i + 1) + "-" + String(doc.artboards[i].name).replace(/[^\w\- ]+/g, "").replace(/\s+/g, "-");
                BG.exportArtboardPNG(doc, new File(folder.fsName + "/" + name + ".png"), i, 0);
            }
        });
        return BG.ok({ folder: folder.fsName, count: n });
    } catch (e) { return BG.fail(e); }
}
